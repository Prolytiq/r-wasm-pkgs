#' Predict Method for \code{bild} Objects
#'
#' @description Obtains predictions (link, response, or dynamic transition probabilities) 
#' from a fitted \code{bild} model object for existing or new data structures.
#'
#' @param object A fitted model object of class \code{\link{bild-class}}.
#' @param newdata Optionally, a data frame in which to look for variables with which to predict. 
#' If omitted, the fitted linear predictors or probabilities from the original fit are returned.
#' @param type The type of prediction required. Use \code{"link"} for the linear predictor scale, 
#' \code{"response"} for the marginal population probability scale, and \code{"transition"} for the 
#' dynamic Markov transition probabilities conditional on the recent lag history.
#' @param ... Additional arguments passed to or from other methods.
#'
#' @return A numeric vector of predicted values or probabilities matching the data rows.
#' 
#' @seealso \code{\link{bild}}, \code{\link{bild-class}}
#' 
#' @examples
#' \donttest{
#' library(bild)
#' 
#' # First-order Markov dependence (MC1)  
#' data(airpollution)
#' 
#' air1 <- bild(wheeze ~ age + smoking, data = airpollution, 
#'              time = "age", aggregate = smoking, dependence = "MC1")
#' 
#' # Standard marginal response prediction on original data
#' pred_mar <- predict(air1, type = "response")
#' head(pred_mar)
#' 
#' # Dynamic transition probabilities on new data (requires y_prev1)
#' new_data_air <- data.frame(
#'   age = c(9, 10, 11, 9, 10, 11),
#'   smoking = factor(c("0", "0", "0", "1", "1", "1")),
#'   y_prev1 = c(0, 1, 0, 1, 1, 0))
#' 
#' dynamic_pred_air <- predict(air1, newdata = new_data_air, type = "transition")
#' print(cbind(new_data_air, Prob_Transition = dynamic_pred_air))
#' 
#' # Second-order Markov with random effects (MC2R) 
#' data(muscatine)
#' muscatine$time1 <- c(-1, 0, 1)
#' muscatine$time2 <- c(1, -2, 1)
#' 
#' Integ <- bildIntegrate(lig = -3.95, lsg = 3.95)
#' musc2r <- bild(obese ~ (time1 + time2) * sex, data = muscatine, 
#'                time = "time1", start = c(1, 1, 1), dependence = "MC2R", integrate = Integ)
#' 
#' # Dynamic transition probabilities for second-order model (requires y_prev1 and y_prev2)
#' new_data_musc <- data.frame(
#'   time1 = c(0, 1),
#'   time2 = c(-2, 1),
#'   sex = factor(c("0", "1")),
#'   y_prev1 = c(1, 0),
#'   y_prev2 = c(0, 1))
#' 
#' dynamic_pred_musc <- predict(musc2r, newdata = new_data_musc, type = "transition")
#' print(cbind(new_data_musc, Prob_Transition = dynamic_pred_musc))
#' }
#' 
#' @importFrom stats qlogis plogis formula delete.response terms model.matrix as.formula
#' @export
predict.bild <- function(object, newdata = NULL, type = c("link", "response", "transition"), ...) {
  type <- match.arg(type)
  
  depend <- if (!is.null(object@call$dependence)) as.character(object@call$dependence) 
  else "ind"
  coef_all <- as.vector(object@coefficients[, 1])
  names_all <- rownames(object@coefficients)
  if (is.null(names_all)) names_all <- names(coef_all)
  
  if (is.null(newdata)) {
    if (type == "link") return(qlogis(object@Fitted))
    if (type == "response") return(object@Fitted)
    if (type == "transition") {
      if (length(object@ind.probability) > 0) return(object@ind.probability)
      return(object@Fitted)}
  }
  
  # Design matrix for new data 
  form <- as.formula(object@call$formula)
  form_right <- formula(delete.response(terms(form, data = object@subset.data)))
  
  orig_data <- object@subset.data
  for (col_name in colnames(newdata)) {
    if (col_name %in% colnames(orig_data)) {
      if (is.factor(orig_data[[col_name]]) && !is.factor(newdata[[col_name]])) {
        newdata[[col_name]] <- factor(newdata[[col_name]], 
                                      levels = levels(orig_data[[col_name]]))}
    }
  }
  
  xlev_orig <- NULL
  if (length(object@f.value) > 0 && any(object@f.value != 0)) {
    factor_name <- deparse(object@call$aggregate)
    if (factor_name %in% colnames(newdata)) {
      xlev_orig <- list()
      xlev_orig[[factor_name]] <- levels(object@f.value)}
  }
  
  X_new <- tryCatch({
    model.matrix(form_right, data = newdata, xlev = xlev_orig)}, error = function(e) {
    stop(paste0("Error generating design matrix from 'newdata': ", e$message))})
  
  n_fixef <- ncol(X_new)
  beta <- as.double(coef_all[1:n_fixef])
  eta <- as.vector(X_new %*% beta)
  
  # Population-averaged transformation if random effects are present
  if (depend %in% c("indR", "MC1R", "MC2R")) {
    omega_idx <- which(names_all %in% c("omega", "log.omega", "sigma2"))
    if (length(omega_idx) == 0) omega_idx <- length(coef_all)
    
    omega <- as.double(coef_all[omega_idx])
    c2 <- (16 * sqrt(3) / (15 * pi))^2
    eta_adj <- eta * (c2 * exp(omega) + 1)^(-0.5)} 
  else {eta_adj <- eta}
  
  if (type == "link") return(eta)
  if (type == "response") return(plogis(eta_adj))
  
  # Dynamic conditional probabilities for Markov dependence structures
  if (type == "transition") {
    if (depend %in% c("ind", "indR")) {
      message("Independent models have no transition structure. Returning marginal probabilities.")
      return(plogis(eta_adj))}
    
    if (!"y_prev1" %in% colnames(newdata)) {
      stop("Column 'y_prev1' must be supplied in 'newdata' for transition predictions.")}
    
    psi1 <- exp(coef_all[which(names_all == "log.psi1")])
    p_marg <- plogis(eta_adj)
    odds_base <- p_marg / (1 - p_marg)
    
    if (depend %in% c("MC1", "MC1R")) {
      y_prev1 <- as.numeric(newdata$y_prev1)
      odds <- odds_base * (sqrt(psi1)^ifelse(y_prev1 == 1, 1, -1))
      return(as.vector(odds / (1 + odds)))}
    
    if (depend %in% c("MC2", "MC2R")) {
      if (!"y_prev2" %in% colnames(newdata)) {
        stop("Column 'y_prev2' must be supplied in 'newdata' 
             for second-order Markov models (MC2).")}
      
      psi2 <- exp(coef_all[which(names_all == "log.psi2")])
      y_prev1 <- as.numeric(newdata$y_prev1)
      y_prev2 <- as.numeric(newdata$y_prev2)
      
      sign1 <- ifelse(y_prev1 == 1, 1, -1)
      sign2 <- ifelse(y_prev2 == 1, 1, -1)
      
      odds <- odds_base * (sqrt(psi1)^sign1) * (sqrt(psi2)^sign2)
      return(as.vector(odds / (1 + odds)))}
  }
}
