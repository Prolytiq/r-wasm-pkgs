#' Autoplot Method for \code{bild} Objects using \code{ggplot2}
#'
#' @description Generates ggplot2-based diagnostic and profile plots for a fitted 
#' \code{bild} longitudinal model object.
#'
#' @param object A fitted model object of class \code{bild}.
#' @param which A numeric value from 1 to 6 specifying the plot type.
#' @param add.unadjusted Logical. 
#' @param subSET An optional logical expression to subset individuals in plot 6.
#' @param ident Logical. 
#' @param ... Further arguments passed.
#'
#' @return A \code{ggplot} object.
#' @examples
#' \donttest{
#' library(ggplot2)
#' library(patchwork)
#' library(bild)
#' data(airpollution)
#' 
#' air1R <- bild::bild(wheeze ~ age + smoking, data = airpollution, time = "age",
#'                aggregate = smoking, dependence = "MC1R")
#' 
#' # Single diagnostic plot (Standardized Residuals vs Time)  
#' autoplot(air1R, which = 2)
#' 
#' # Multi-panel diagnostic plots using patchwork
#' (autoplot(air1R, which = 5) + autoplot(air1R, which = 2)) /
#'    (autoplot(air1R, which = 1) + autoplot(air1R, which = 3))
#' 
#' # Individual mean profiles for the smoker group
#' autoplot(air1R, which = 6, subSET = smoking == "1", ident = TRUE)
#' }
#' @importFrom stats plogis acf pacf na.pass
#' @importFrom methods slotNames
#' @import ggplot2
#' @method autoplot bild
#' @export
autoplot.bild <- function(object, which = 5, add.unadjusted = FALSE, subSET, ident = FALSE, ...) 
{
  if (!requireNamespace("ggplot2", quietly = TRUE)) {
    stop("The 'ggplot2' package is required to use this function.")
  }
  Time <- Probability <- Group <- Type <- Residuals <- Fitted <- 
    Lag <- ACF <- PACF <- ID <- NULL
  
  # Base objects extracted from the S4 slots
  time_vec    <- object@Time
  unique_time <- unique(time_vec)
  n_time      <- length(unique_time)
  depend      <- if (!is.null(object@call$dependence)) as.character(object@call$dependence) else "ind"
  
  # 1. Residuals vs Fitted Values
  if (which == 1) {
    fit_res_data <- data.frame(
      Fitted = object@Fitted.av,
      Residuals = object@s.residuals
    )
    
    g <- ggplot(fit_res_data, aes(x = Fitted, y = Residuals)) +
      geom_hline(yintercept = 0, linetype = "dashed", color = "gray50") +
      geom_point(color = "darkslategrey", size = 2, alpha = 0.7) +
      labs(title = NULL, subtitle = "Residuals vs Fitted", 
           x = "Fitted values", y = "Standardized residuals") +
      theme_classic()
    return(g)
  }
  
  # 2. Standardized Residuals vs Time
  if (which == 2) {
    res_data <- data.frame(Time = unique_time, Residuals = object@s.residuals)
    
    g <- ggplot(res_data, aes(x = Time, y = Residuals)) +
      geom_hline(yintercept = 0, linetype = "dashed", color = "gray50") +
      geom_linerange(aes(ymin = 0, ymax = Residuals), linewidth = 0.8, color = "steelblue") +
      geom_point(color = "firebrick", size = 2.5) +
      labs(title = NULL, subtitle = "Standardized Residuals vs Time", 
           x = "Time", y = "Standardized Residuals") +
      theme_classic() +
      scale_x_continuous(breaks = pretty(unique_time))
    return(g)
  }
  
  # 3. ACF of Residuals
  if (which == 3) {
    acf_obj <- acf(object@s.residuals, plot = FALSE, na.action = na.pass)
    acf_data <- data.frame(Lag = as.numeric(acf_obj$lag), ACF = as.numeric(acf_obj$acf))
    ci <- 2 / sqrt(length(object@s.residuals))
    
    g <- ggplot(acf_data, aes(x = Lag, y = ACF)) +
      geom_hline(yintercept = 0, color = "gray50") +
      geom_hline(yintercept = c(-ci, ci), linetype = "dashed", color = "firebrick") +
      geom_segment(aes(xend = Lag, yend = 0), linewidth = 1, color = "steelblue") +
      labs(title = NULL, subtitle = "ACF residuals", x = "Lag", y = "ACF") +
      theme_classic()
    return(g)
  }
  
  # 4. PACF of Residuals
  if (which == 4) {
    pacf_obj <- pacf(object@s.residuals, plot = FALSE, na.action = na.pass)
    pacf_data <- data.frame(Lag = as.numeric(pacf_obj$lag), PACF = as.numeric(pacf_obj$acf))
    ci <- 2 / sqrt(length(object@s.residuals))
    
    g <- ggplot(pacf_data, aes(x = Lag, y = PACF)) +
      geom_hline(yintercept = 0, color = "gray50") +
      geom_hline(yintercept = c(-ci, ci), linetype = "dashed", color = "firebrick") +
      geom_segment(aes(xend = Lag, yend = 0), linewidth = 1, color = "steelblue") +
      labs(title = NULL, subtitle = "PACF residuals", x = "Lag", y = "PACF") +
      theme_classic()
    return(g)
  }
  
  # 5. Estimated Parametric Profiles
  if (which == 5) {
    x4 <- unique(object@model.matrix)
    coef <- object@coefficients
    npar <- length(coef)
    
    n.col <- ncol(x4)
    coef1 <- as.double(coef[1:n.col])
    eta <- x4 %*% coef1
    
    f_val <- object@f.value
    level_f <- unique(f_val)
    ncurves <- length(level_f)
    
    factor_name <- deparse(object@call$aggregate)
    if (factor_name == "NULL" || length(object@call$aggregate) == 0) {
      factor_name <- "Group"
    }
    
    plot_data <- data.frame()
    n1 <- 1
    
    for (j1 in 1:ncurves) {
      n2 <- j1 * n_time
      group_label <- if (ncurves > 1) as.character(level_f[j1]) else "All"
      
      df_curve <- data.frame(
        Time = unique_time,
        Probability = plogis(eta[n1:n2]),
        Group = group_label,
        Type = "Parametric Fit",
        stringsAsFactors = FALSE
      )
      
      if (depend %in% c("indR", "MC1R", "MC2R")) {
        omega <- as.double(coef[npar])
        c2 <- (16 * sqrt(3) / (15 * pi))^2
        eta_c <- eta * (c2 * exp(omega) + 1)^(-0.5)
        
        df_curve_c <- data.frame(
          Time = unique_time,
          Probability = plogis(eta_c[n1:n2]),
          Group = group_label,
          Type = "Adjusted Parametric Fit",
          stringsAsFactors = FALSE
        )
        
        if (add.unadjusted) {
          plot_data <- rbind(plot_data, df_curve, df_curve_c)
        } else {
          plot_data <- rbind(plot_data, df_curve_c)
        }
      } else {
        plot_data <- rbind(plot_data, df_curve)
      }
      n1 <- n2 + 1
    }
    
    g <- ggplot(plot_data, aes(x = Time, y = Probability, color = Group, linetype = Type)) +
      geom_line(linewidth = 0.8) +
      geom_point(size = 2) +
      labs(title = NULL, subtitle = "Parametric Mean Profiles", 
           x = "Time", y = "Probability", color = factor_name) +
      theme_classic() +
      ylim(0, 1) +
      scale_x_continuous(breaks = pretty(unique_time)) +
      theme(legend.position = "bottom")
    
    if (length(unique(plot_data$Type)) == 1) {
      g <- g + guides(linetype = "none")
    } else {
      g <- g + labs(linetype = "Fit Type")
    }
    return(g)
  }
  
  # 6. Individual Mean Profiles
  if (which == 6) {
    if (!depend %in% c("indR", "MC1R", "MC2R")) {
      stop("Individual mean profiles are only available for models with random effects.")
    }
    
    n.id <- object@n.cases
    aa_matrix <- matrix(object@Fitted, n.id, n_time, byrow = TRUE)
    data_subset <- object@subset.data
    id_list <- unique(data_subset$id)
    
    ind_data <- data.frame()
    for (i in 1:n.id) {
      ind_data <- rbind(ind_data, data.frame(
        ID = as.character(id_list[i]),
        Time = unique_time,
        Probability = as.vector(aa_matrix[i, ]),
        stringsAsFactors = FALSE))
    }
    
    if (!missing(subSET)) {
      id_selected <- eval(substitute(subSET), data_subset, parent.frame())
      valid_ids <- unique(data_subset$id[id_selected])
      ind_data <- ind_data[ind_data$ID %in% as.character(valid_ids), ]
    }
    
    g <- ggplot(ind_data, aes(x = Time, y = Probability, group = ID)) +
      geom_line(linewidth = 0.5, color = "grey40", alpha = 0.7) +
      labs(title = NULL, subtitle = "Individual mean profiles", x = "Time", y = "Probability") +
      theme_classic() +
      ylim(0, 1) +
      scale_x_continuous(breaks = pretty(unique_time), expand = expansion(mult = c(0.05, 0.3)))
    
    if (ident) {
      label_data <- do.call(rbind, lapply(unique(ind_data$ID), function(id_j) {
        sub_id <- ind_data[ind_data$ID == id_j, ]
        sub_id[which.max(sub_id$Time), ]}))
      
      g <- g + geom_text(data = label_data, 
                         aes(label = ID), 
                         size = 3, 
                         hjust = -0.5, 
                         color = "black")
    }
    return(g)
  }
  
  stop("'which' must be between 1 and 6.")
}