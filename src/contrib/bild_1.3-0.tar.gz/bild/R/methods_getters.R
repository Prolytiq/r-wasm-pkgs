#' @include classes_and_generics.R
NULL

#' @title Extract the Akaike Information Criterion
#' @name getAIC
#' @aliases getAIC,bild-method
#' @param object an object of class \code{\link{bild}}.
#' @return Returns a numeric value corresponding to the AIC of the fitted model.
#' @seealso \code{\link{bild-class}}
#' @export
setMethod("getAIC", "bild", 
          function(object) { return(object@aic) })

#' @title Extract Log-Likelihood
#' @name getLogLik
#' @aliases getLogLik,bild-method
#' @param object an object of class \code{\link{bild}}.
#' @return Returns a numeric value corresponding to the log-Likelihood of the fitted model.
#' @seealso \code{\link{bild-class}}
#' @export
setMethod("getLogLik", "bild", function(object) { return(object@log.likelihood) })

#' @title Extract the coefficient estimates
#' @name getcoef
#' @aliases getcoef,bild-method
#' @param object an object of class \code{\link{bild}}.
#' @return Returns the coefficient estimates of the fitted model (a matrix).
#' @seealso \code{\link{bild-class}}
#' @export
setMethod(f = "getcoef","bild",
          function (object) { return(object@coefficients)})

#' @title Extract variance-covariance matrix
#' @name getvcov
#' @aliases getvcov,bild-method
#' @param object an object of class \code{\link{bild}}.
#' @return Returns a numeric matrix corresponding to the variance-covariance matrix 
#' of the fitted model.
#' @seealso \code{\link{bild-class}}
#' @export
setMethod("getvcov", "bild",
          function(object) 
          {
            cov <- object@covariance
            cnames <- rownames(cov)
            r1 <- nrow(cov)
            c1 <- ncol(cov)
            
            if(all(is.na(match(cnames, "omega")))) {
              return(cov)  }
            else if (!all(is.na(match(cnames, "omega")))) {
              cov.aux <- cov[1:(r1 - 1), 1:(c1 - 1), drop = FALSE]
              return(cov.aux)  }
          })

#' @title Extract conditional random effects
#' @name randeff
#' @aliases randeff,bild-method
#' @param object an object of class \code{\link{bild}}.
#' @return A data frame containing the random effects estimates, if the model 
#' contains random effects. Otherwise, it issues a warning.
#' @seealso \code{\link{bild-class}}
#' @export
setMethod("randeff", "bild",
          function(object) {
            coef <- object@coefficients
            bi.est <- object@bi.estimate
            nas <- is.na(coef[, 1])
            
            cnames <- rownames(coef)[!nas]
            if (is.null(cnames)) cnames <- names(coef[, 1])[!nas]
            
            if (!all(is.na(match(cnames, "omega")))) {
              n.cases <- length(bi.est)
              tabela2 <- as.data.frame(matrix(as.double(bi.est), nrow = n.cases, ncol = 1))
              dimnames(tabela2) <- list(c(1:n.cases), "(Intercept)")
              return(tabela2) } 
            
            else {warning("\nOnly available for Random effects models.") }
          })

#' @title Extract variance estimates of random effects (wrapper)
#' @name vareff
#' @aliases vareff,bild-method
#' @param object an object of class \code{\link{bild}}.
#' @return A data frame containing the variance estimate.
#' @seealso \code{\link{getVariance}}
#' @export
setMethod("vareff", "bild", function(object) {
  return(getVariance(object, se = FALSE))
})

#' @title Extract fixed effects estimates
#' @name fixeff
#' @aliases fixeff,bild-method
#' @param object an object of class \code{\link{bild}}.
#' @return A matrix or vector containing the fixed effects estimates.
#' @seealso \code{\link{bild-class}}
#' @export
setMethod("fixeff", "bild",
          function(object) 
          {
            coef <- object@coefficients
            nas <- is.na(coef[, 1])
            cnames <- rownames(coef)
            if (is.null(cnames)) cnames <- names(coef[, 1])
            
            coef <- coef[!nas, , drop = FALSE]
            cnames <- cnames[!nas]
            
            exclude_names <- c("omega", "log.psi1", "log.psi2")
            keep_idx <- !(cnames %in% exclude_names)
            
            return(coef[keep_idx, 1])
          })

#' @title Extract the fixed effects model matrix
#' @name model.mat
#' @aliases model.mat,bild-method
#' @param object an object of class \code{\link{bild}}.
#' @return Returns the fixed effects model matrix of the fitted model.
#' @seealso \code{\link{bild-class}}
#' @export
setMethod("model.mat", "bild",
          function(object) {
            return(object@model.matrix)
          })

#' @title Fitted values for 'bild' objects
#' @name fitted.bild
#' @aliases fitted,bild-method
#' @param object an object of class \code{\link{bild}}.
#' @param ... Additional arguments.
#' @return A numeric vector of the fitted values.
#' @seealso \code{\link{bild-class}}, \code{\link{fitted}}
#' @export
setMethod(f = "fitted", "bild", 
          function(object, ...) { 
            fit_values <- object@Fitted
            names(fit_values) <- seq_along(fit_values)
            return(round(fit_values, 6))
          })

#' @title Extract variance estimates of random effects
#' @name getVariance
#' @aliases getVariance,bild-method
#' @description 
#' These functions extract the variance estimate of the random effect (\eqn{\sigma^2 = \exp(\omega)}) 
#' from an object of class \code{bild}. 
#' @param object an object of class \code{\link{bild}}.
#' @param se logical; if \code{TRUE}, includes the standard error of the variance 
#' If \code{se = TRUE}, it also includes the standard error calculated via the Delta method.
#' \code{vareff} is a wrapper for \code{getVariance} with \code{se = FALSE} for 
#' backward compatibility.
#' @return A data frame containing the variance estimate.
#' @export
setMethod("getVariance", "bild", function(object, se = FALSE) {
  coefs <- object@coefficients
  
  if (!("omega" %in% rownames(coefs))) {
    warning("\nOnly available for Random effects models.")
    return(NULL)}
  
  # variance (sigma^2)
  var_est <- exp(coefs["omega", 1])
  if (!se) { 
    return(data.frame(Variance = var_est, row.names = "(Intercept)"))}
  
  #  SE via Delta method 
  omega_se <- object@se["omega"]
  var_se   <- var_est * omega_se 
  
  return(data.frame(Estimate = var_est, Std.Error = var_se, 
                    row.names = "(Intercept)" ))
})


# TIDYVERSE 

#' @title Tidy a \code{bild} object into a tibble
#' @rdname tidy-bild
#' @method tidy bild
#' @param x A fitted model object of class \code{bild}.
#' @param conf.int Logical. Whether or not to include a confidence interval 
#' in the tidied output. Defaults to \code{FALSE}.
#' @param conf.level The confidence level to use for the confidence interval 
#' if \code{conf.int = TRUE}. Defaults to \code{0.95}.
#' @param ... Additional arguments. Not used.
#' @return A \code{tibble::tibble} containing columns: term, estimate, std.error, 
#' statistic, p.value, conf.low, conf.high.
#' @details 
#' For parameters estimated on the log-scale (such as dependence parameters 
#' \code{log.psi1}, \code{log.psi2}) and the random effect variance parameter 
#' \code{omega}, \code{tidy.bild} automatically transforms the estimates to their 
#' natural scale (\code{psi1}, \code{psi2}, \code{sigma2}) via the exponential 
#' function. Consequently, their standard errors are adjusted using the Delta method, 
#' and confidence intervals are computed accordingly.
#' @examples
#' \donttest{
#' library(bild)
#' library(generics)
#' data(airpollution)
#' air1R <- bild::bild(wheeze ~ age + smoking, data = airpollution, time = "age",
#'                aggregate = smoking, dependence = "MC1R")
#' tidy(air1R, conf.int = TRUE)
#' }
#' @importFrom methods slotNames
#' @importFrom stats pnorm qnorm
#' @importFrom tibble as_tibble
#' @importFrom generics tidy
#' @export
tidy.bild <- function(x, conf.int = FALSE, conf.level = 0.95, ...) {
  coef_raw <- x@coefficients
  
  if (is.matrix(coef_raw) || is.data.frame(coef_raw)) {
    estimates <- as.numeric(coef_raw[, 1])
    cnames <- rownames(coef_raw)} 
  else {
    estimates <- as.numeric(coef_raw)
    cnames <- names(coef_raw)}
  
  nas <- is.na(estimates)
  estimates <- estimates[!nas]
  cnames <- cnames[!nas]
  available_slots <- slotNames(x)
  std_errors <- rep(NA, length(estimates))
  
  if ("se" %in% available_slots && length(x@se) > 0) {
    se_raw <- x@se
    
    if (is.matrix(se_raw) || is.data.frame(se_raw)) {
      se_vals <- as.numeric(se_raw[, 1])} 
    else {se_vals <- as.numeric(se_raw)}
    
    std_errors <- se_vals[!nas]} 
  else if ("covariance" %in% available_slots && length(x@covariance) > 0) {
    std_errors <- sqrt(diag(x@covariance))[!nas]}
  
  n_terms <- length(estimates)
  final_terms <- character(n_terms)
  final_est <- numeric(n_terms)
  final_se <- numeric(n_terms)
  final_low <- if (conf.int) numeric(n_terms) else rep(NA_real_, n_terms)
  final_high <- if (conf.int) numeric(n_terms) else rep(NA_real_, n_terms)
  
  alpha <- 1 - conf.level
  crit_z <- qnorm(1 - alpha / 2)
  
  for (i in seq_len(n_terms)) {
    cur_name <- cnames[i]
    cur_est <- estimates[i]
    cur_se <- std_errors[i]
    
    if (cur_name %in% c("omega", "log.psi1", "log.psi2") && !is.na(cur_se)) {
      final_terms[i] <- switch(cur_name, "omega"    = "sigma2",
                               "log.psi1" = "psi1", "log.psi2" = "psi2")
      final_est[i] <- exp(cur_est)
      final_se[i]  <- exp(cur_est) * cur_se
      
      if (conf.int) {
        raw_low  <- cur_est - crit_z * cur_se
        raw_high <- cur_est + crit_z * cur_se
        final_low[i]  <- exp(raw_low)
        final_high[i] <- exp(raw_high)}
    } 
    else {
      final_terms[i] <- cur_name
      final_est[i] <- cur_est
      final_se[i]  <- cur_se
      
      if (conf.int && !is.na(cur_se)) {
        final_low[i]  <- cur_est - crit_z * cur_se
        final_high[i] <- cur_est + crit_z * cur_se}
    }
  }
  
  statistic <- final_est / final_se
  p_value   <- 2 * pnorm(-abs(statistic))
  
  td <- data.frame(
    term        = final_terms,
    estimate    = final_est,
    std.error   = final_se,
    statistic   = statistic,
    p.value     = p_value,
    conf.low    = final_low,
    conf.high   = final_high,
    stringsAsFactors = FALSE)
  
  if (requireNamespace("tibble", quietly = TRUE)) {
    td <- tibble::as_tibble(td)}
  
  return(td)
}

#' @title Glance at a \code{bild} object
#' @rdname glance-bild
#' @description Glance at a fitted longitudinal model object of class \code{bild} 
#' to extract a single-row summary tibble with key statistics.
#'
#' @method glance bild
#' @param x A fitted model object of class \code{bild}.
#' @param ... Additional arguments. Not used.
#' @return A \code{tibble::tibble} with summary statistics (number of observations, 
#' degrees of freedom/parameters, log-likelihood, AIC, and BIC).
#'
#' @examples
#' \donttest{
#' library(bild)
#' library(generics)
#' data(airpollution)
#' air1R <- bild::bild(wheeze ~ age + smoking, data = airpollution, time = "age",
#'                aggregate = smoking, dependence = "MC1R")
#' glance(air1R)
#' }
#'
#' @importFrom methods slotNames
#' @importFrom tibble as_tibble
#' @importFrom generics glance
#' @export
glance.bild <- function(x, ...) {
  available_slots <- slotNames(x)
  
  n_obs <- if ("model.matrix" %in% available_slots && length(x@model.matrix) > 0) {
    nrow(x@model.matrix)} 
  else if ("subset.data" %in% available_slots && length(x@subset.data) > 0) {
    nrow(x@subset.data)} 
  else {x@n.cases}
  
  if ("residuals" %in% available_slots && length(x@residuals) > 0) {
    n_obs <- sum(!is.na(x@residuals))}
  
  n_pars <- if (is.matrix(x@coefficients)) nrow(x@coefficients) else length(x@coefficients)
  
  aic_val <- NULL
  if ("aic" %in% available_slots) {
    aic_val <- as.numeric(x@aic)} 
  else if ("AIC" %in% available_slots) {
    aic_val <- as.numeric(x@AIC)} 
  else {aic_val <- NA }
  
  log_lik <- NA
  if ("log.likelihood" %in% available_slots) {
    log_lik <- as.numeric(x@log.likelihood)} 
  else if ("logLik" %in% available_slots) {
    log_lik <- as.numeric(x@logLik)} 
  else if ("loglik" %in% available_slots) {
    log_lik <- as.numeric(x@loglik) }
  
  if (is.na(log_lik) && !is.na(aic_val)) {
    log_lik <- (2 * n_pars - aic_val) / 2}
  
  bic_val <- if (!is.na(log_lik)) -2 * log_lik + n_pars * log(n_obs) else NA
  
  gl <- data.frame(
    nobs   = n_obs,
    df     = n_pars,
    logLik = log_lik,
    AIC    = aic_val,
    BIC    = bic_val,
    stringsAsFactors = FALSE)
  
  if (requireNamespace("tibble", quietly = TRUE)) {
    gl = tibble::as_tibble(gl)}
  
  return(gl)
}