#' Analysis of Deviance for 'bild' objects
#'
#' @description Computes an analysis of deviance table for two or more fitted model 
#' objects of class \code{bild}.
#'
#' @param object An object of class \code{\link{bild}}.
#' @param ... Additional objects of class \code{\link{bild}}.
#' @param test Logical. If TRUE, the likelihood ratio test is performed. Default is TRUE.
#' @param correct Logical. If TRUE, a correction for the likelihood ratio test is 
#' applied (e.g., for mixture models). Default is FALSE.
#'
#' @details 
#' Setting \code{correct = TRUE} is used to test the presence of a random intercept term; 
#' the solution proposed by Self and Liang (1987) is adopted for the p-value.
#'
#' @note 
#' The comparison between two models by \code{anova} will only be valid if they 
#' are fitted to the same dataset.
#'
#' @references 
#' Self, Steven G. and Liang, Kung-Yee (1987). Asymptotic properties of maximum 
#' likelihood estimators and likelihood ratio tests under nonstandard conditions. 
#' \emph{Journal of the American Statistical Association}, 82, 605-610.
#'
#' @examples
#' \donttest{
#' data(locust)
#' loc1 <- bild::bild(move~(time+I(time^2))*feed*sex, data=locust, dependence="MC1")
#' loc2 <- bild::bild(move~(time+I(time^2))*feed, data=locust, dependence="MC1")
#' anova(loc1, loc2)
#'
#' data(muscatine)
#' muscatine$time1 <- c(-1, 0, 1)
#' musc1 <- bild::bild(obese~time1, data=muscatine, time="time1", dependence="MC1")
#' musc1r <- bild::bild(obese~time1, data=muscatine, time="time1", dependence="MC1R")
#' anova(musc1, musc1r, correct=TRUE)
#' }
#' @importFrom stats pnorm
#' @exportMethod anova
setMethod("anova", signature(object = "bild"), 
          function(object, ..., test = TRUE, correct = FALSE) {
            
            models <- list(object, ...)
            
            if (length(models) < 2) 
              stop("anova is only implemented for 2 or more 'bild' objects.")
            if (length(models) > 2)
              warning("anova output is optimized for pairwise comparisons. Only the first two models will be evaluated.")
            
            m1 <- models[[1]]
            m2 <- models[[2]]
            
            if (m1@n.cases != m2@n.cases)
              stop("All models must be fit to the same data object.")
            
            if (identical(m1@call$formula, m2@call$formula) && 
                identical(m1@call$dependence, m2@call$dependence))
              stop("Models are identical.")
            
            if (length(m1@coefficients) >= length(m2@coefficients)) { 
              gen <- m1 
              red <- m2} 
            else { 
              gen <- m2
              red <- m1}
            
            df <- length(gen@coefficients) - length(red@coefficients)
            bic1 <- -2 * gen@log.likelihood + length(gen@coefficients) * log(length(gen@Time))
            bic2 <- -2 * red@log.likelihood + length(red@coefficients) * log(length(red@Time))
            
            tab_df <- data.frame(
              Model  = c("Model 1 (General)", "Model 2 (Reduced)"),
              AIC    = round(c(gen@aic, red@aic), 3),
              BIC    = round(c(bic1, bic2), 3),
              logLik = round(c(gen@log.likelihood, red@log.likelihood), 4),
              stringsAsFactors = FALSE)
            
            if (test) {
              lrt <- 2 * (gen@log.likelihood - red@log.likelihood)
              if (lrt < 0) {
                lrt <- 0
                warning("Log-likelihood of the general model is smaller than the reduced model. LRT set to 0.")
              }
              
              p_val <- if (correct) 0.5 * (1 - pchisq(lrt, df)) else 1 - pchisq(lrt, df)
              
              tab_df$Deviance  <- c(NA, round(lrt, 3))
              tab_df$df        <- c(NA, round(df, 0)) 
              tab_df$`p-value` <- c(NA, formatC(p_val, format = "e", digits = 3))
            }
            
            cat("\nData:", deparse(gen@call$data), "\n")
            cat("Model 1:", deparse(gen@call$formula), "; Dependence:", as.character(gen@call$dependence), "\n")
            cat("Model 2:", deparse(red@call$formula), "; Dependence:", as.character(red@call$dependence), "\n\n")
            print(tab_df, row.names = FALSE, na.print = " ")
          }
)

#' Summary of a 'bild' object
#'
#' @description Summary method for class \code{bild}. Computes and prints 
#' summary statistics for a fitted \code{bild} object.
#'
#' @param object an object of class \code{\link{bild}}.
#' @param cov logical. If TRUE, prints the covariance matrix of coefficients.
#' @param cor logical. If TRUE, prints the correlation matrix of coefficients.
#' 
#' @return Returns the summary object (invisibly).
#' 
#' @seealso \code{\link{bild}}, \code{\link{bild-class}}
#' 
#' @exportMethod summary
setMethod("summary",
          signature(object = "bild"),
          function(object, cov = FALSE, cor = FALSE) {
            
            cat("\nCall:\n")
            print(object@call)
            cat("\nNumber of profiles in the dataset: ", object@ni.cases)
            cat("\nNumber of profiles used in the fit: ", object@n.cases)
            cat("\nDependence structure:", as.character(object@call$dependence))
            cat("\nLog likelihood: ", round(object@log.likelihood, 4))
            cat("\nAIC: ", round(object@aic, 4), "\n")
            
            coef_raw <- object@coefficients
            nas <- is.na(coef_raw[, 1])
            cnames <- names(coef_raw[, 1][!nas])
            if (is.null(cnames)) cnames <- rownames(coef_raw)[!nas]
            
            est <- coef_raw[, 1][!nas]
            se <- object@se[, 1][!nas]
            z_val <- est / se
            p_val <- 2 * pnorm(-abs(z_val))
            
            coef_table <- cbind(Estimate = est, "Std. Error" = se, "z value" = round(z_val, 3), "p-value" = round(p_val, 6))
            rownames(coef_table) <- cnames
            if (any(is.na(coef_table))) {
              warning("Some coefficients were not estimated (NA values present). Results might be unreliable.")
            }
            
            # Dependence: "ind"
            if(all(is.na(match(cnames, "log.psi1"))) && all(is.na(match(cnames, "omega")))) {
              cat("\nFixed effects:\t\n")
              print(coef_table)
            }
            # Dependence: "MC1"
            else if(!all(is.na(match(cnames, "log.psi1"))) && all(is.na(match(cnames, "log.psi2"))) && all(is.na(match(cnames, "omega")))) {
              cat("\nFixed effects:\t\n")
              print(coef_table[1:(nrow(coef_table)-1), , drop = FALSE])
              cat("\nDependence parameter: \t\n")
              print(coef_table[nrow(coef_table), , drop = FALSE])
            }
            # Dependence: "MC2"
            else if(!all(is.na(match(cnames, "log.psi1"))) && !all(is.na(match(cnames, "log.psi2"))) && all(is.na(match(cnames, "omega")))) {
              cat("\nFixed effects:\t\n")
              print(coef_table[1:(nrow(coef_table)-2), , drop = FALSE])
              cat("\nDependence parameter: \t\n")
              print(coef_table[(nrow(coef_table)-1):nrow(coef_table), , drop = FALSE])
            }
            # Dependence: "indR"
            else if (all(is.na(match(cnames, "log.psi1"))) && all(is.na(match(cnames, "log.psi2"))) && !all(is.na(match(cnames, "omega")))) {
              dep_params <- "omega"
              fixed_params_idx <- !(rownames(coef_table) %in% dep_params)
              
              cat("\nFixed effects:\t\n")
              print(coef_table[fixed_params_idx, , drop = FALSE])
              
              omega_row <- coef_table[rownames(coef_table) == "omega", , drop = FALSE]
              
              cat("\nRandom effect (omega):\t\n")
              df_rand <- data.frame(
                "Estimate" = round(omega_row[1, 1], 4),
                "Std Error" = round(omega_row[1, 2], 4),
                row.names = "(Intercept)")
              print(df_rand)
              cat("\nNote: Variance (sigma2) =", round(exp(omega_row[1, 1]), 4), "\n")
            }
            # Dependence: "MC1R"
            else if (!all(is.na(match(cnames, "log.psi1"))) && all(is.na(match(cnames, "log.psi2"))) && !all(is.na(match(cnames, "omega")))) {
              dep_params <- c("log.psi1", "omega")
              fixed_params_idx <- !(rownames(coef_table) %in% dep_params)
              
              cat("\nFixed effects:\t\n")
              print(coef_table[fixed_params_idx, , drop = FALSE])
              
              cat("\nParameters for the dependence structure:\t\n")
              print(coef_table[rownames(coef_table) == "log.psi1", , drop = FALSE])
              
              omega_row <- coef_table[rownames(coef_table) == "omega", , drop = FALSE]
              
              cat("\nRandom effect (omega):\t\n")
              df_rand <- data.frame(
                "Estimate" = round(omega_row[1, 1], 4),
                "Std Error" = round(omega_row[1, 2], 4),
                row.names = "(Intercept)")
              print(df_rand)
              cat("\nNote: Variance (sigma2) =", round(exp(omega_row[1, 1]), 4), "\n")
            }
            # Dependence: "MC2R"
            else if (!all(is.na(match(cnames, "log.psi1"))) && !all(is.na(match(cnames, "log.psi2"))) && !all(is.na(match(cnames, "omega")))) {
              dep_params <- c("log.psi1", "log.psi2", "omega")
              fixed_params_idx <- !(rownames(coef_table) %in% dep_params)
              
              cat("\nFixed effects:\t\n")
              print(coef_table[fixed_params_idx, , drop = FALSE])
              
              cat("\nParameters for the dependence structure:\t\n")
              print(coef_table[rownames(coef_table) %in% c("log.psi1", "log.psi2"), , drop = FALSE])
              
              omega_row <- coef_table[rownames(coef_table) == "omega", , drop = FALSE]
              
              cat("\nRandom effect (omega):\t\n")
              df_rand <- data.frame(
                "Estimate" = round(omega_row[1, 1], 4),
                "Std Error" = round(omega_row[1, 2], 4),
                row.names = "(Intercept)")
              print(df_rand)
              cat("\nNote: Variance (sigma2) =", round(exp(omega_row[1, 1]), 4), "\n")
            }
            
            if (cov) { 
              cat("\nCovariance of Coefficients: \n")
              print(object@covariance, digits = 2) 
            }
            if (cor) { 
              cat("\nCorrelation of Coefficients: \n")
              print(object@correlation, digits = 2) 
            }
            cat("\nMessage: ", object@message, "\n")
            
            invisible(object)
          }
)

#' Show a 'bild' object
#'
#' @description \code{show} displays a brief summary of a fitted \code{bild} 
#' model object, including the function call, the number of profiles used 
#' in the fit, the number of estimated coefficients, the maximized log-likelihood, 
#' and any convergence message.
#'
#' @param object An object of class \code{\link{bild}}.
#' 
#' @return No return value, called for side effects (printing to the console).
#' 
#' @seealso \code{\link{bild-class}}
#' 
#' @importFrom methods show
#' @exportMethod show
setMethod("show",
          signature(object = "bild"),
          function (object) 
          {
            cat("\nCall:\n") 
            dput(object@call)
            cat("\nNumber of profiles used in the fit:", object@n.cases, "\n")
            cat("\nNumber of Coefficients:", length(object@coefficients), "\n")
            cat("\nLog likelihood:", round(object@log.likelihood, 4), "\n\n")
            cat("Message: ", object@message, "\n")
          }
)