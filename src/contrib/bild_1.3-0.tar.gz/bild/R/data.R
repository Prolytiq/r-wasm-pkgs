#' Locust dataset
#' 
#' @description This data set was presented by MacDonald and Raubenheimer (1995) 
#' and analyzes the effect of hunger on locomotory behaviour of 24 locusts 
#' (\emph{Locusta migratoria}) observed at 161 time points.
#' 
#' @format A data frame with 3864 observations on the following 5 variables:
#' \describe{
#'   \item{\code{id}}{a numeric vector that identifies the number of the individual profile.}
#'   \item{\code{move}}{a numeric vector representing the response variable (1="moving", 0="not moving").}
#'   \item{\code{sex}}{a factor with levels 1 for "male" and 0 for "female".}
#'   \item{\code{time}}{a numeric vector that identifies the number of the time points observed.}
#'   \item{\code{feed}}{a factor with levels 0 "no" and 1 "yes".}
#' }
#' @source MacDonald, I. and Raubenheimer, D. (1995). Hidden Markov models and animal behaviour. 
#' \emph{Biometrical Journal}, 37, 701-712.
#' 
#' @examples
#' data(locust)
#' str(locust)
#' 
#' \donttest{
#' # Dependence="MC2" (Fast computation)
#' locust2_feed1 <- bild(move ~ (time + I(time^2)) * sex, data = locust, 
#'      subSET = feed == "1", aggregate = sex, dependence = "MC2")
#' summary(locust2_feed1)
#' 
#' # Base plot diagnostics (Standard)
#' plot(locust2_feed1, which = 5, ylab = "probability of locomoting", 
#'       main = "Feed=1", add.unadjusted = TRUE)
#' 
#' # ggplot2-based diagnostic plots (New)
#' library(ggplot2)
#' # Comparing which=5 with the base plot above
#' autoplot(locust2_feed1, which = 5) 
#' 
#' # Other diagnostic plots
#' autoplot(locust2_feed1, which = 1)
#' autoplot(locust2_feed1, which = 2)
#' }
"locust"

#' Muscatine dataset
#' 
#' @description This example is a subset of data from the Muscatine Coronary Risk Factor Study, 
#' a longitudinal study of coronary risk factors in school children from Muscatine (Iowa, USA).
#' 
#' @format A data frame with 156 observations on the following 5 variables:
#' \describe{
#'   \item{\code{id}}{identifies the number of the individual profile.}
#'   \item{\code{obese}}{a numeric vector that identifies the obesity status (1="yes", 0="no").}
#'   \item{\code{sex}}{a factor with levels 1 for "female" and 0 for "male".}
#'   \item{\code{time}}{a numeric vector (1,2,3) indicating the observed time points.}
#'   \item{\code{counts}}{a numeric vector indicating the number of times that each profile is replicated.}
#' }
#' @source Fitzmaurice, G. M., Laird, N. M. and Lipsitz, S. R. (1994). Analyzing incomplete longitudinal binary 
#' responses: a likelihood based approach. \emph{Biometrics}, 38, 602-612.
#' 
#' @examples
#' data(muscatine)
#' str(muscatine)
#' 
#' # we decompose the time effect in orthogonal components
#' muscatine$time1 <- c(-1, 0, 1)
#' muscatine$time2 <- c(1, -2, 1)
#' 
#' \donttest{
#' # second order Markov Chain without random effects
#' musc2 <- bild(obese~(time1+time2)*sex, data=muscatine,  
#'      time="time1", aggregate=sex, trace=TRUE, dependence="MC2")
#' 
#' summary(musc2)
#' getAIC(musc2)
#' getLogLik(musc2)
#' fitted(musc2)
#' }
"muscatine"

#' Airpollution dataset
#' 
#' @description This example is a subset of data from the Six Cities study, a longitudinal study 
#' of the health effects of air pollution (Ware, J. H. et al., 1984).
#' 
#' @format A data frame with 128 observations on the following 5 variables:
#' \describe{
#'   \item{\code{id}}{identifies the number of the individual profile, containing 32 individual profiles.}
#'   \item{\code{wheeze}}{a numeric vector that identifies the wheezing status (1="yes", 0="no").}
#'   \item{\code{age}}{a numeric vector corresponding to the age in years since the child's 9th birthday.}
#'   \item{\code{smoking}}{a factor that identifies if the mother smokes (1="smoke", 0="no smoke").}
#'   \item{\code{counts}}{a numeric vector corresponding to the replications of each individual profile.}
#' }
#' @details The data set presented by Fitzmaurice and Laird (1993) contains complete records 
#' on 537 children from Steubenville, Ohio. The repeated binary response is the wheezing 
#' status of a child. Maternal smoking status was determined in the first interview and 
#' treated as a time-independent covariate.
#' 
#' @source Fitzmaurice, G. M. and Laird, N. M. (1993). A Likelihood-Based Method for analyzing 
#' Longitudinal Binary Response. \emph{Biometrika}, 80, 141-51.
#' 
#' @examples
#' data(airpollution)
#' str(airpollution)
#' 
#' # Dependence="MC2"
#' air2 <- bild(wheeze~age+smoking, data=airpollution, time="age",
#'              aggregate=smoking, dependence="MC2")
#' summary(air2)
#' getAIC(air2)
#' getLogLik(air2)
#' 
#' # Base graphics diagnostics
#' plot(air2)
#' 
#' # ggplot2-based diagnostics
#' library(ggplot2)
#' autoplot(air2, which = 1) # Residuals vs Fitted values
#' autoplot(air2, which = 2) # Standardized Residuals vs Time
#' autoplot(air2, which = 5) # Estimated Parametric Profiles
#' 
#' \donttest{
#' # Multi-panel diagnostic plots using patchwork
#' library(patchwork)
#' (autoplot(air2, which = 5) + autoplot(air2, which = 2)) /
#'   (autoplot(air2, which = 1) + autoplot(air2, which = 3))
#' 
#' # Dependence="MC2R"
#' air2r <- bild(wheeze~age+smoking, data=airpollution, time="age",
#'               aggregate=smoking, dependence="MC2R")
#' summary(air2r)
#' 
#' # Compare base plot with autoplot for individual profiles
#' plot(air2r, which=6, subSET=smoking=="0", main="smoking==0", ident=TRUE) 
#' autoplot(air2r, which=6, subSET=smoking=="0", ident=TRUE)
#' }
"airpollution"