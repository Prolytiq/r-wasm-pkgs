#' Class "summary.bild"
#'
#' @description Summary of \code{\link{bild}} objects. Extracted from a \code{bild} object, 
#' it contains values meant for printing by the \code{show} method.
#'
#' @slot coefficients Matrix. Estimated parameters.
#' @slot se Matrix. Standard errors of estimated parameters.
#' @slot covariance Matrix. Covariance of estimated parameters.
#' @slot correlation Matrix. Correlation of estimated parameters.
#' @slot log.likelihood Numeric. The value of the log likelihood.
#' @slot message Integer. Information returned by the optimizer.
#' @slot n.cases Numeric. Number of individual profiles used in the optimization procedure.
#' @slot ni.cases Numeric. Number of individual profiles in the dataset.
#' @slot aic Numeric. The Akaike information criterion.
#' @slot call Language. The call that generated the \code{bild} object.
#' 
#' @seealso 
#' \code{\link{bild}}, 
#' \code{\link[methods]{show}}
#' 
#' @importFrom methods setClass
#' @exportClass summary.bild
setClass("summary.bild", 
         slots = list(
           coefficients = "matrix", 
           se = "matrix", 
           covariance = "matrix", 
           correlation = "matrix", 
           log.likelihood = "numeric", 
           message = "integer", 
           n.cases = "numeric", 
           ni.cases = "numeric", 
           aic = "numeric", 
           call = "language"))

#' Class "bild" for Results of a Maximum Likelihood Estimation
#'
#' @description This class encapsulates results of a maximum likelihood procedure 
#' and is usually created as the result of a call to \code{\link{bild}}.
#'
#' @slot coefficients Matrix. Estimated parameters.
#' @slot se Matrix. Standard errors of estimated parameters.
#' @slot covariance Matrix. Covariance of estimated parameters.
#' @slot correlation Matrix. Correlation of estimated parameters.
#' @slot log.likelihood Numeric. The value of the log likelihood.
#' @slot message Integer. Information returned by the optimizer.
#' @slot n.cases Numeric. Number of individual profiles used in the optimization.
#' @slot ni.cases Numeric. Number of individual profiles in the dataset.
#' @slot aic Numeric. The Akaike information criterion.
#' @slot residuals Numeric. The residuals of estimated parameters.
#' @slot s.residuals Numeric. The residuals summed over the individual profile.
#' @slot ind.probability Numeric. The transition probabilities.
#' @slot prob.matrix Matrix. The matrix of transition probabilities.
#' @slot Fitted Numeric. The fitted values for the estimated parameters.
#' @slot bi.estimate Matrix. The estimated values for the individual random effects.
#' @slot Fitted.av Numeric. The average fitted values.
#' @slot Time Numeric. Vector of time points.
#' @slot model.matrix Matrix. The model matrix.
#' @slot y.matrix Matrix. The matrix of response values.
#' @slot subset.data Data.frame. The data subset if considered.
#' @slot y.av Numeric. The average of the response value over an individual profile.
#' @slot f.value Factor. Indicates the aggregation factor if present.
#' @slot call Language. The call to \code{"bild"}.
#'
#' @seealso 
#' \code{\link{bild-class}}, 
#' \code{\link[methods]{show}}
#'   
#' @importFrom methods setClass
#' @exportClass bild
setClass("bild", 
         slots = list(
           coefficients = "matrix", 
           se = "matrix", 
           covariance = "matrix", 
           correlation = "matrix", 
           log.likelihood = "numeric", 
           message = "integer",
           n.cases = "numeric", 
           ni.cases = "numeric", 
           aic = "numeric", 
           residuals = "numeric", 
           s.residuals = "numeric", 
           ind.probability = "numeric", 
           prob.matrix = "matrix", 
           Fitted = "numeric", 
           bi.estimate = "matrix",
           Fitted.av = "numeric", 
           Time = "numeric", 
           model.matrix = "matrix", 
           y.matrix = "matrix",
           subset.data = "data.frame", 
           y.av = "numeric", 
           f.value = "factor", 
           call = "language"))

# GENERIC METHODS 

#' @importFrom methods setGeneric

#' @noRd
setGeneric("getAIC", def=function(object) standardGeneric("getAIC"))

#' @noRd
setGeneric("getLogLik", def=function(object) standardGeneric("getLogLik"))

#' @noRd
setGeneric("getcoef", def=function(object) standardGeneric("getcoef"))

#' @noRd
setGeneric("getvcov", def=function(object) standardGeneric("getvcov"))

#' @noRd
setGeneric("randeff", def=function(object) standardGeneric("randeff"))

#' @noRd
setGeneric("fixeff", def=function(object) standardGeneric("fixeff"))

#' @noRd
setGeneric("vareff", def=function(object) standardGeneric("vareff"))

#' @noRd
setGeneric("selectform", def=function(object) standardGeneric("selectform"))

#' @noRd
setGeneric("model.mat", def=function(object) standardGeneric("model.mat"))

#' @noRd
setGeneric("getVariance", function(object, se = FALSE) standardGeneric("getVariance"))