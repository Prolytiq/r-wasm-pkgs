#' @importFrom grDevices dev.interactive devAskNewPage extendrange
#' @importFrom graphics abline legend lines mtext par text
#' @importFrom methods new
#' @importFrom stats binomial coef glm lm na.omit optim pchisq
"_PACKAGE"