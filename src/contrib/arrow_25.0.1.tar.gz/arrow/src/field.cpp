// Licensed to the Apache Software Foundation (ASF) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The ASF licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

#include "./arrow_types.h"

#include <arrow/type.h>
#include <arrow/util/key_value_metadata.h>

// [[arrow::export]]
std::shared_ptr<arrow::Field> Field__initialize(
    const std::string& name, const std::shared_ptr<arrow::DataType>& field,
    bool nullable = true) {
  return arrow::field(name, field, nullable);
}

// [[arrow::export]]
std::string Field__ToString(const std::shared_ptr<arrow::Field>& field) {
  return field->ToString();
}

// [[arrow::export]]
std::string Field__name(const std::shared_ptr<arrow::Field>& field) {
  return field->name();
}

// [[arrow::export]]
bool Field__Equals(const std::shared_ptr<arrow::Field>& field,
                   const std::shared_ptr<arrow::Field>& other, bool check_metadata) {
  return field->Equals(other, check_metadata);
}

// [[arrow::export]]
bool Field__HasMetadata(const std::shared_ptr<arrow::Field>& field) {
  return field->HasMetadata();
}

// [[arrow::export]]
cpp11::writable::list Field__metadata(const std::shared_ptr<arrow::Field>& field) {
  auto meta = field->metadata();
  int64_t n = 0;
  if (field->HasMetadata()) {
    n = meta->size();
  }
  cpp11::writable::list out(n);
  std::vector<std::string> names_out(n);
  for (int i = 0; i < n; i++) {
    out[i] = cpp11::as_sexp(meta->value(i));
    names_out[i] = meta->key(i);
  }
  out.names() = names_out;
  return out;
}

// [[arrow::export]]
std::shared_ptr<arrow::Field> Field__WithMetadata(
    const std::shared_ptr<arrow::Field>& field, cpp11::strings metadata) {
  auto values = cpp11::as_cpp<std::vector<std::string>>(metadata);
  auto names = cpp11::as_cpp<std::vector<std::string>>(metadata.attr("names"));
  auto kv =
      std::make_shared<arrow::KeyValueMetadata>(std::move(names), std::move(values));
  return field->WithMetadata(std::move(kv));
}

// [[arrow::export]]
std::shared_ptr<arrow::Field> Field__RemoveMetadata(
    const std::shared_ptr<arrow::Field>& field) {
  return field->RemoveMetadata();
}

// [[arrow::export]]
bool Field__nullable(const std::shared_ptr<arrow::Field>& field) {
  return field->nullable();
}

// [[arrow::export]]
std::shared_ptr<arrow::DataType> Field__type(const std::shared_ptr<arrow::Field>& field) {
  return field->type();
}
