## these tests may fail if run a second time in the same session, because of the once-per-session warning throttling
f <- ~ 1 + (1|f)
test_that("deprecation warnings from lme4 formula processing", {
  expect_warning(subbars(f), "has moved")
  expect_warning(nobars(f), "has moved")
  expect_warning(findbars(f), "has moved")
  expect_warning(mkReTrms(findbars(f), fr = data.frame(f = factor(1:10))), "has moved")
  expect_warning(expandDoubleVerts(f), "has moved")
})

test_that("reOnly shims", {
  reo <- reOnly(Reaction ~ 1 + (1|Subject))
  expect_equal(reo, ~(1 | Subject))
})
