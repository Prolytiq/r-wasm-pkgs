# Contributing to igraph

This outlines how to propose a change to igraph.

## Fixing typos

You can fix typos, spelling mistakes, or grammatical errors in the documentation directly using the GitHub web interface, 
as long as the changes are made in the _source_ file. 
This generally means you'll need to edit [roxygen2 comments](https://roxygen2.r-lib.org/articles/roxygen2.html) in an `.R`, not a `.Rd` file. 
You can find the `.R` file that generates the `.Rd` by reading the comment in the first line.

## Bigger changes

If you want to make a bigger change, it's a good idea to first file an issue and make sure someone from the team agrees that it’s needed. 
If you’ve found a bug, 
please file an issue that illustrates the bug with a minimal [reprex](https://www.tidyverse.org/help/#reprex) 
(this will also help you write a unit test, if needed).
See the tidyverse guide on [how to create a great issue](https://code-review.tidyverse.org/issues/) for more advice.

### Dependencies installation

To install all dependencies of igraph, including dependencies needed for development, call, from the root of the rigraph Git repository:

```r
# All Imports and Suggests dependencies
pak::pak()
# Then install packages like roxygen2 add-ons
pak::pak(dependencies = "Config/Needs/build")
```

### Pull request process

*   Fork the package and clone onto your computer. 
    If you haven't done this before, you can use `usethis::create_from_github("igraph/rigraph", fork = TRUE)`.

*   Install all development dependencies with `pak::pak()`, 
    and then make sure the package passes R CMD check by running `devtools::check()`. 
    If R CMD check doesn't pass cleanly, it's a good idea to ask for help before continuing. 
*   Create a Git branch for your pull request (PR). 
    You can use [usethis](https://usethis.r-lib.org/articles/pr-functions.html), GitHub Desktop, etc.

*   Make your changes, commit to git, and then create a PR.
    The title of your PR should briefly describe the change.
    The body of your PR should contain `Fixes #issue-number`.

### Code style

*   New code should follow the tidyverse [style guide](https://style.tidyverse.org). 
    You can use the [styler](https://CRAN.R-project.org/package=styler) package to apply these styles, but please don't restyle code that has nothing to do with your PR.  

*  We use [roxygen2](https://cran.r-project.org/package=roxygen2), 
   with [Markdown syntax](https://cran.r-project.org/web/packages/roxygen2/vignettes/rd-formatting.html), 
   for documentation. 
   We aspire to document internal functions using [devtag](https://github.com/moodymudskipper/devtag) (not all of them are thus documented yet).

*  We use [testthat](https://cran.r-project.org/package=testthat) for unit tests. 
   Please add test cases for the change you are proposing, or ask us for help.
   
### Naming conventions

* Use `max` for maximal and `largest` for maximum.

### Test files

We strive to align script and test names. 
This is still a work-in-progress but the goal is to have code from `R/name.R` tested in `tests/testthat/test-name.R`.
This allows easy toggling between the two files thanks to `usethis::use_test()` and `usethis::use_r()`.

## Code of Conduct

Please note that the igraph project is released with a [Contributor Code of Conduct](https://igraph.org/code-of-conduct.html). 
By contributing to this project you agree to abide by its terms.
