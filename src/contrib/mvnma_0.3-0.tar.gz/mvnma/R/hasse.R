#' Hasse diagram
#' 
#' @description
#' This function generates a Hasse diagram for a partial order of treatment
#' ranks in a multivariate network meta-analysis.
#' 
#' @param x An object of class \code{\link{mvrank}}.
#' @param \dots Additional arguments passed on to
#'   \code{\link[netmeta]{hasse.netposet}}.
#' 
#' @details
#' Generate a Hasse diagram (Carlsen & Bruggemann, 2014) for a partial order of
#' treatment ranks in a network meta-analysis (Rücker & Schwarzer, 2017).
#' 
#' This R function is a wrapper function for
#' \code{\link[netmeta]{hasse.netposet}}.
#'
#' @return
#' A Hasse diagram is shown in the active graphics window.
#' 
#' @references
#' Carlsen L, Bruggemann R (2014):
#' Partial order methodology: a valuable tool in chemometrics.
#' \emph{Journal of Chemometrics},
#' \bold{28}, 226--34
#'
#' Rücker G, Schwarzer G (2017):
#' Resolve conflicting rankings of outcomes in network meta-analysis:
#' Partial ordering of treatments.
#' \emph{Research Synthesis Methods},
#' \bold{8}, 526--36
#'                                             
#' @examples
#' # Locate file "mvnma_examples.rda" with mvnma() results
#' .fname <- system.file("extdata/mvnma_examples.rda", package = "mvnma")
#' load(.fname)
#' 
#' # Print odds ratios for efficacy outcomes
#' outc <- names(mvnma12)[names(mvnma12) != "cor"]
#' #
#' for (i in outc) {
#'   cat(paste0("\nOutcome: ", i, "\n\n"))
#'   print(round(exp(mvnma12[[i]]$TE.random), 2))
#' }
#' 
#' # Rank treatments using SUCRAs
#' ranks12 <- mvrank(mvnma12, method = "sucra",
#'   small.values = c("undes", "undes"))
#' ranks12
#' 
#' # Get the Hasse diagram for the efficacy outcomes
#' hasse(ranks12)
#' 
#' @method hasse mvrank
#' @export

hasse.mvrank <- function(x, ...) {
  
  chkclass(x, "mvrank")
  x <- updateversion(x)
  #
  method <- attr(x, "method")
  #
  if (!(method %in% c("SUCRA", "pbest")))
    stop("Hasse diagram can only be produced for ",
         "'method = \"SUCRA\"' and 'method = \"pbest\"'.",
         call. = FALSE)
  
  # Get rid of warning "no visible binding for global variable"
  treatment <- NULL
  
  treats <- E <- new_treats <- vector("list")
  #
  for (i in seq_along(x))
    treats[[i]] <- x[[i]]$treatment  
  #
  all_treats <- unique(unlist(treats))
  
  for (i in seq_along(x)) {
    E[[i]] <- which(!(all_treats %in% x[[i]]$treatment))
    #
    if (length(E[[i]]) > 0) {
      new_treats[[i]] <- cbind.data.frame(all_treats[E[[i]]], NA)
      names(new_treats[[i]]) <- names(x[[i]])
      #
      x[[i]] <- rbind.data.frame(x[[i]], new_treats[[i]])
    }
    #
    x[[i]] %<>% arrange(treatment)
    row.names(x[[i]]) <- x[[i]]$treatment
    #
    x[[i]]$treatment <- NULL
  } 
  #
  ranking_mat <- list.cbind(x) 
  names(ranking_mat) <- names(x)
  #
  po <- netposet(ranking_mat, outcomes = names(ranking_mat))
  #
  hasse(po, ...)
  #
  invisible(NULL)
}
