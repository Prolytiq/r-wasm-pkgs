#' Network graph for objects of class netcomb
#' 
#' @description
#' This function generates a graph of the evidence network.
#' 
#' @param x An object of class \code{netcomb}.
#' @param \dots Additional arguments passed on to
#'   \code{\link{netgraph.netmeta}}.
#' 
#' @author Guido Schwarzer \email{guido.schwarzer@@uniklinik-freiburg.de},
#'   Gerta Rücker \email{gerta.ruecker@@uniklinik-freiburg.de}
#' 
#' @seealso \code{\link{netcomb}}, \code{\link{netgraph.netmeta}}
#' 
#' @keywords hplot
#' 
#' @examples
#' # Only consider studies including Face-to-face PST (to reduce
#' # runtime of example)
#' #
#' face <- subset(Linde2016, id %in% c(16, 24, 49, 118))
#' 
#' # Use pairwise() to transform data to comparison-based format
#' #
#' pw <- pairwise(treat = int,
#'   event = resp, n = n, studlab = paste(author, year),
#'   data = face, reference = "plac", sm = "OR")
#' 
#' # Conduct random effects network meta-analysis
#' #
#' nma <- netmeta(pw, common = FALSE)
#' 
#' # Additive model for treatment components (with placebo as inactive
#' # treatment)
#' #
#' cnma <- netcomb(nma, inactive = "placebo")
#'
#' netgraph(cnma)
#' 
#' @method netgraph netcomb
#' @export

netgraph.netcomb <- function(x, ...) {
  
  
  chkclass(x, "netcomb")
  
  
  res <- netgraph(x$x, ...)
  
  
  invisible(res)
}
