#' Amlodipine for Work Capacity
#' 
#' @description
#' Meta-analysis on the effect of amlodipine on work capacity.
#' 
#' This meta-analysis is used as a data example in Hartung and Knapp (2001).
#' 
#' @name amlodipine
#'
#' @docType data
#'
#' @format
#'
#' A data frame with the following columns:
#' \tabular{rl}{
#' \bold{\emph{study}}\tab study label \cr
#' \bold{\emph{n.amlo}}\tab number of observations in amlodipine group
#'   \cr
#' \bold{\emph{mean.amlo}}\tab estimated mean in amlodipine group \cr
#' \bold{\emph{var.amlo}}\tab variance in amlodipine group \cr
#' \bold{\emph{n.plac}}\tab number of observations in placebo group
#'   \cr
#' \bold{\emph{mean.plac}}\tab estimated mean in placebo group \cr
#' \bold{\emph{var.plac}}\tab variance in placebo group
#' }
#' 
#' @seealso \code{\link{metacont}}
#' 
#' @source
#' Hartung J & Knapp G (2001):
#' On tests of the overall treatment effect in meta-analysis with
#' normally distributed responses.
#' \emph{Statistics in Medicine},
#' \bold{20}, 1771--82
#' 
#' @keywords datasets
#' 
#' @examples
#' data(amlodipine)
#' 
#' ma <- metacont(n.amlo, mean.amlo, sqrt(var.amlo),
#'   n.plac, mean.plac, sqrt(var.plac),
#'   data = amlodipine, studlab = study,
#'   method.tau = "DL")
#' ma.hk <- update(ma, method.random.ci = "HK")
#' 
#' # Same results for mean difference as in Table III in Hartung and
#' # Knapp (2001)
#' #
#' vars.common <- c("TE.common", "lower.common", "upper.common")
#' vars.random <- c("TE.random", "lower.random", "upper.random")
#' #
#' res.common <- as.data.frame(ma[vars.common])
#' names(res.common) <- vars.random
#' #
#' res.md <- rbind(res.common,
#'   as.data.frame(ma[vars.random]),
#'   as.data.frame(ma.hk[vars.random]))
#' #
#' res.md <- round(res.md, 5)
#' #
#' row.names(res.md) <- c("CE", "RE", "RE (HaKn)")
#' names(res.md) <- c("Absolute difference", "CI lower", "CI upper")
#' #
#' res.md

NULL
